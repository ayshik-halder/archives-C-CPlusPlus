#include<iostream>

int main(){
    int num = 5 ;
    std::cout << "Value: " << num << std::endl ;
    std::cout << "Address: " << &num << std::endl ; //& returns memory address
    return 0; 
    
}