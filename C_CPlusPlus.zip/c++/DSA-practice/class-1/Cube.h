#pragma once

    class Cube  
    {
    public:
        double getVolume();
        double getSurfaceArea();
        void setlength(double length);

    private:
        double length_;
   
    };
