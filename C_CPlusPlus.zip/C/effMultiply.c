#include<stdio.h>
void main()
{
	int i=8;
	int sum;
	sum=(i<<3)-i;
	printf("\n Ans %d ",sum);
}
