#include<stdio.h>
int main()
{
	char s;
	printf("\n Enter character:  ");
	scanf("%c",&s);
	printf("\n %d",s);
}
