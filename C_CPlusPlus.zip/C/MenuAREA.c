//menu driven C prog to calculate the area of circle,rectangle, square,triangle using fx
#include<stdio.h>
#include<math.h>
void main()
{
	int ch;
	printf("\n ________AREA_______\n");
	printf("\n Enter Choice :");
    scanf("%d",&ch);
    switch(ch)
    {
    	case 1:
    		cir();
    		break;
    	case 2:
    		rect();
    		break;
    	case 3:
    		sqr();
    		break;
    	case 4:
    		tri();
    		break;
    	default:
    		printf("\n Wrong choice");
	}
	return 0;
}
void circle()
{
	
}
	
	
	
	
	
}
